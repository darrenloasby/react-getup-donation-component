/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "components_CustomStepper_js";
exports.ids = ["components_CustomStepper_js"];
exports.modules = {

/***/ "./components/CustomStepper.js":
/*!*************************************!*\
  !*** ./components/CustomStepper.js ***!
  \*************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react_form_stepper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-form-stepper */ \"react-form-stepper\");\n/* harmony import */ var react_form_stepper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_form_stepper__WEBPACK_IMPORTED_MODULE_1__);\n\nvar _jsxFileName = \"/project/sandbox/components/CustomStepper.js\";\n// CustomStepper.js\n\n\nconst CustomStepper = ({\n  steps,\n  activeStep,\n  styleConfig\n}) => {\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_form_stepper__WEBPACK_IMPORTED_MODULE_1__.Stepper, {\n    steps: steps,\n    activeStep: activeStep,\n    styleConfig: styleConfig\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 6,\n    columnNumber: 5\n  }, undefined);\n};\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (CustomStepper);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9yZWFjdC1ob29rLWZvcm0tbXVsdGktc3RlcC1mb3JtLy4vY29tcG9uZW50cy9DdXN0b21TdGVwcGVyLmpzPzEyMzUiXSwibmFtZXMiOlsiQ3VzdG9tU3RlcHBlciIsInN0ZXBzIiwiYWN0aXZlU3RlcCIsInN0eWxlQ29uZmlnIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFDQTs7QUFFQSxNQUFNQSxhQUFhLEdBQUcsQ0FBQztBQUFFQyxPQUFGO0FBQVNDLFlBQVQ7QUFBcUJDO0FBQXJCLENBQUQsS0FBd0M7QUFDNUQsc0JBQ0UsOERBQUMsdURBQUQ7QUFBUyxTQUFLLEVBQUVGLEtBQWhCO0FBQXVCLGNBQVUsRUFBRUMsVUFBbkM7QUFBK0MsZUFBVyxFQUFFQztBQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFHRCxDQUpEOztBQU1BLCtEQUFlSCxhQUFmIiwiZmlsZSI6Ii4vY29tcG9uZW50cy9DdXN0b21TdGVwcGVyLmpzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gQ3VzdG9tU3RlcHBlci5qc1xuaW1wb3J0IHsgU3RlcHBlciB9IGZyb20gXCJyZWFjdC1mb3JtLXN0ZXBwZXJcIjtcblxuY29uc3QgQ3VzdG9tU3RlcHBlciA9ICh7IHN0ZXBzLCBhY3RpdmVTdGVwLCBzdHlsZUNvbmZpZyB9KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPFN0ZXBwZXIgc3RlcHM9e3N0ZXBzfSBhY3RpdmVTdGVwPXthY3RpdmVTdGVwfSBzdHlsZUNvbmZpZz17c3R5bGVDb25maWd9IC8+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBDdXN0b21TdGVwcGVyO1xuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/CustomStepper.js\n");

/***/ })

};
;